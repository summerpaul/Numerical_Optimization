###Homework

This is the second section of L2 homework, a little difficult.

Implement smooth trajectory generation by C++

TODO:

path_smoothing->gcopter->include->gcopter->cublic_spline/lbfgs/path_smoother

write your code in the '//TODO' and complete the program.

Tips: if you have finish the first section of the homework, you can just apply the lbfgs.hpp to this project.